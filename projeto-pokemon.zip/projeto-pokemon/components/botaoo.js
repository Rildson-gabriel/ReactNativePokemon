import { Text, View, Button, StyleSheet } from 'react-native';

export default function AssetExample() {
  return (
    <View>
      <Button
    title="▼ VER MAIS"
    color="#d63b3b"
    accessibilityLabel="Learn more about this purple button"
/>
    </View>
  );
}